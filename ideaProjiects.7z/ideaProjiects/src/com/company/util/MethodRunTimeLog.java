package com.company.util;

import java.lang.annotation.*;

/**
 * User: weichun.zhan
 * Date: 12-10-25
 * Time: 下午4:09
 */

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface MethodRunTimeLog {

    boolean debug() default false;

}