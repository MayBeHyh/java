package com.company.sys;

import com.company.util.FileUtil;
import com.company.util.MethodRunTimeLog;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    @MethodRunTimeLog(debug = true)
    public static void main(String[] args) throws IOException {
        InputStreamReader isr=new InputStreamReader(System.in);
        BufferedReader br =new BufferedReader(isr);
        System.out.println("请录入一个文件夹路径");
        String line=br.readLine();
        System.out.println("请录入一个用于模糊查询文件名的字符串");
        String line1=br.readLine();
        //查询文件开始时间
        long startTime = System.currentTimeMillis();
        //文件夹
        File file = new File(line);       //封装成File对象，对其进行判断
        if (!file.exists()) {
            System.out.println("您录入的文件夹路径不存在，请重新录入");
        } else if (!file.isDirectory()) {
            System.out.println("你录入的是文件路径，请重新录入");
        }
        List<String> fileNames = new ArrayList<>();
        FileUtil.getFilesName(fileNames,file.getPath(),line1);
        if(fileNames != null && fileNames.size() > 0)
        {
            System.out.println(MessageFormat.format("共查询到{0}个文件！", fileNames.size()));
        }
        fileNames.forEach(s->{
            System.out.println(s);
        });
        //查询文件结束时间
        long endTime = System.currentTimeMillis();
        //查询文件运行时间
        System.out.println("运行时间为：" + (endTime - startTime) + "毫秒");

    }
}
